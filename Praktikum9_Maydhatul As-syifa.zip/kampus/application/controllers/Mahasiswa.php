<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {
    public function index(){
        $this->load->model('Mahasiswa_model','mahasiswa');
        $list_mhs = $this->mahasiswa->getAll();

        $data['list_mahasiswa']=$list_mhs;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/index',$data);
        $this->load->view('layout/footer');
        
    }

    public function view(){
        $nim = $this->input->get('id');
        $this->load->model('Mahasiswa_model','mahasiswa');
        $data['mhs'] = $this->mahasiswa->findById($nim);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/view',$data);
        $this->load->view('layout/footer');
    }

    public function create(){
        $data['judul']='Form Kelola Mahasiswa';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/create',$data);
        $this->load->view('layout/footer');
    }
    
    public function save(){
        $this->load->model('mahasiswa_model','mahasiswa');

        $nim= $this->input->post('nim');
        $nama = $this->input->post('nama');
        $gender = $this->input->post('gender');
        $tmp_lahir = $this->input->post('tmp_lahir');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $prodi = $this->input->post('prodi');
        $ipk = $this->input->post('ipk');
        $idedit = $this->input->post('idedit');

        $data_mhs[]=$nim;
        $data_mhs[]=$nama;
        $data_mhs[]=$gender;
        $data_mhs[]=$tmp_lahir;
        $data_mhs[]=$tgl_lahir;
        $data_mhs[]=$prodi;
        $data_mhs[]=$ipk;

        if(isset($idedit)){
            // update data lama
            $data_mhs[]=$idedit;
            $this->mahasiswa->update($data_mhs);
        }else{
            // save data baru
            $this->mahasiswa->save($data_mhs); 
        }

        redirect(base_url().'index.php/mahasiswa/view?id='.$nim, 'refresh');
    }

    public function edit(){
        $id = $this->input->get('id');
        $this->load->model("mahasiswa_model","mahasiswa");
        $mhsedit = $this->mahasiswa->findById($id);

        $data['judul']='Form Kelola Mahasiswa';
        $data['mhsedit']=$mhsedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/update',$data);
        $this->load->view('layout/footer');

    }

    public function delete(){
        $id = $this->input->get('id');
        $this->load->model("mahasiswa_model","mahasiswa");
        $this->mahasiswa->delete($id);
        redirect(base_url().'index.php/mahasiswa/index', 'refresh');
    }
}